These files are PostScript formatted schematics of the
new WA4DSY 56KB RF Modem.  They are 8.5 x 11 inches
in size.  There are a total of 4 pages.

These schematics include all the changes through
Sept. 26, 1995.  They should NOT be considered
final and accurate.  Other changes may be made
before production begins.
  


