extern void exitPGP(int);
