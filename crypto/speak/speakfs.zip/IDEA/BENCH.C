#define BENCHMARK	200

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "idea.h"

void main()
{
	DWORD start, t;
	double e;
	int i;
	unsigned short iv[8];
	unsigned char key[] = "Cobble up some key for this benchmark.";
	static unsigned char buffer[8000]; 

	printf("Running benchmark: please be patient.\n");
	initcfb_idea(iv, key, FALSE);    
    start = GetTickCount();
    for (i = 0; i < BENCHMARK; i++) {
    	ideacfb(buffer, sizeof buffer);
	}
	t = GetTickCount() - start; 
	e = (((double) BENCHMARK * (sizeof buffer) * 1000.0) / t);
//	printf("%ld bytes in %ld milliseconds:\n", (long) BENCHMARK * (sizeof buffer), t);                 
	printf("%.0f bytes per second.\n", e);                
    printf("\nPlease E-mail the line:\n\n    %.0f\n\nalong with a description of your machine\n", e);
    printf("(for example 486/50) to kelvin@fourmilab.ch.\n\nThank you!\n");
}
