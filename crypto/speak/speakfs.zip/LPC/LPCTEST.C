#include <stdio.h>
#include "lpc.h"

/*#define ENCODE/**/
/*#define DECODE/**/

main(argc, argv)
  int argc;
  char **argv;
{
  int nbytes;
  unsigned char buf[180];
  lpcparams_t params;

fprintf(stderr, "S = %d\n", sizeof params);
  lpc_init(sizeof(buf));
#ifndef DECODE
  while ((nbytes = read(0, buf, sizeof(buf))) > 0) {
	lpc_analyze(buf, &params);
#else
  while ((nbytes = read(0, &params, sizeof(params))) > 0) {
#endif
#ifdef ENCODE
	write(1, &params, sizeof params);
#else
	nbytes = lpc_synthesize(&params, 1.0, buf);
	write(1, buf, nbytes);
#endif
  }
}
