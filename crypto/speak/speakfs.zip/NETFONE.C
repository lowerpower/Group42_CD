/*

				Main program
				
*/

#include "netfone.h"

//	WINMAIN  --  Main application entry point

INT PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrev,
				   LPSTR pszCmdLine, INT nCmdShow)
{
    MSG msg;
    LPSTR cp;
    
    /*	Allocate a large message queue to handle getting behind in
    	output buffer disposal.  */
    	
    while (SetMessageQueue(messageQueueSize) == 0) {
    	messageQueueSize--;
    }
    
    //	Disable floating point error interrupts
    
    _control87(_EM_ZERODIVIDE | _EM_OVERFLOW | _EM_INVALID,
    		   _EM_ZERODIVIDE | _EM_OVERFLOW | _EM_INVALID);
    
    //	Check for and process "start iconic" command line switch
    
    if ((cp = _fstrstr(pszCmdLine, "-S")) != NULL ||
    	(cp = _fstrstr(pszCmdLine, "/S")) != NULL ||
    	(cp = _fstrstr(pszCmdLine, "-s")) != NULL ||
    	(cp = _fstrstr(pszCmdLine, "/s")) != NULL) {
    	if ((cp == pszCmdLine || isspace(cp[-1])) &&
    		(cp[2] == 0 || isspace(cp[2]))) {
    		nCmdShow = SW_SHOWMINIMIZED;
    		_fmemcpy(cp, "  ", 2);
    	}
    } 
    
	//	Initialise application

    if (!InitApplication(hInstance)) {
        return FALSE;
    }
    
    //	Initialise instance

    if (!InitInstance(hInstance, pszCmdLine, nCmdShow)) {
        return FALSE;
    }

	//	MDI message dispatching loop

    while (GetMessage(&msg, 0, 0, 0)) {
    	if (!((hDlgPropeller != NULL && IsDialogMessage(hDlgPropeller, &msg)) ||
    		(hDlgAnswer != NULL && IsDialogMessage(hDlgAnswer, &msg)))
    		) {
	        if (!TranslateMDISysAccel(hwndMDIClient, &msg) &&
	            !TranslateAccelerator(hwndMDIFrame, hAccel, &msg)) {
	            TranslateMessage(&msg);
	            DispatchMessage(&msg);
	        }
        }
    }
    return msg.wParam;
}

