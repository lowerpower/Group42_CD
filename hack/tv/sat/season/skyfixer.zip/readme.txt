skyfixer [<COM port number>] [wa<us>] [wb<us>] [wc<iterations>] [d] [e] [m] [p]
[i<VCL input file>] [o<VCL output file] [d<debug log file>]
	
'wa30000' = 30000�s delay after card RESET   'p' = passive mode
'wb500'   = 500�s delay after each sent byte 'd' = packet screen log mode
'wc150'   = issue wait command after 150     'e' = economy mode (slow machines!)
	    kernel iterations                'm' = suppress osd messages
'dvcdebug'= write debug file 'vcdebug'       'n' = suppress nano debug info

Keyboard:  <+/->=in/decrease wb value by 100   <N>=toggle nano debug mode
<Q/X/ESC>=quit  <L>=write c-formatted log file <D>=toggle packet debug mode
<H>=toggle iso-header dump mode                <K>=toggle 0x74 packet log mode


skyfixer2.02:
-------------
-Due to a little bug the answer messages have been corrupted. The bug
affected only those answer packages that haven`t been proceddes by the
nano code parser. Today, Sky changed (disarmed) its code, so the bug
became active.
-ZKT implemented
-Channel identification fixed (todays code change affected also the
 routine that extracted the subchannel ID)
 Nickelodeon`s sub ID 07 has been added.
If you live e.g. in Germany, you must modify the skyfixer binary in order
to disable the decryption of MTV,TAC,EUR.,ZEE-TV. These channels can be
legally subscribed to! Decrypting them without such a subscription is
illegal!
Take a file editor and change the Byte at the file offset address $b2cd:
-find the byte stream: f1 01 00 67 3d
-modify the 00 byte    f1 01 01 67 3d
 and write it back to disk.

skyfixer2.01:
-------------
more speed optimisations 
now the 'VCLOG' logfile output works :-| (due to a little bug in the public 
version it always said 'nothing to log', but since there were no complaints 
about it, I just didn't notice it, too)
There comes an example source code with this archive, that shows you how you
may use the vclog-file for own debugging adventures ;-)
A rather mindless iso-header dump option has been included.

Using this software in order to avoid subscription payment is illegal.
In GERMANY you aren't able to subscribe to the BSkyB channels, however,
you are able to subscribe to MTV, ZeeTV, Adult Channel, Eurotica.
If you don't have a subscription to those channels, this software must
not be used to watch them illegaly. Anyway, I implemented an option
that disables the program from decoding these channels. In order to
achive that, you have to alter a byte in the executable.
Take a binary editor and watch out for this byte stream:
(file offset $ae45)

f1 01 00 67 3d
      ^^
change it into:

f1 01 01 67 3d
      ^^
and write it back to disk. Now this version isn't able to decode the
mentioned channels any more.
     
skyfixer2.0:
------------
it's supposed to work on 8086 machines, too - at least that
compiler option has been set. ;-) However, I made some modifications
to the kernel routine to let it do its work a little bit faster.
There is also another parameter: wc. It causes the 'smart card' to issue
a wait command after the given number of kernel calls. This only prevents
the decoder to timeout too early...
A value of 150 is set by default. A value of 0..10 would be rather stupid,
because the wait command will then be issued after almost each kernel call
(let there be other data traffic, too!).
Anyway, I think you'll never have to change it...

I changed the format of the logfile 'VCLOG'. Now, it contains the 0x74
and the corresponding 0x78 package in a c-formatted text output.
When pressing <k> you may select which packages will have to be be logged:
All 0x74 packages or all those packages that contain nano code.
(In this case, the 0x78 field is filled with zeros).
Of course, the VCL file format remains unchanged.

The TV-OSD should always show the correct channel name, at least it
does so on SVA1 & pace ird.

enjoy !
