README.DOC

The SSN program, version 3.00 is a simple reference tool that can
come in handy for investigators, lawyers, cops, employers, or anyone
else who needs reference information about Social Security Numbers.

The program is simple to use.  Just type the program name to enter
interactive mode.  Type each number you want to check at the
prompt.  The program will display your results, and continue to
prompt you until you quit by pressing the escape key.  It is not
necessary to type dashes between the SSN fields.  The program will
insert them for you.  However, if you are in the habit of typing
them, the program will ignore your extraneous keystrokes.

There are four valid command line formats:

1.  SSN <enter> will run the interactive mode, writing results to the
    console until you press <esc>.

2.  SSN [nnn-nn-nnnn] will run a single inquiry, display the results,
    and return you to the DOS prompt.

2.  SSN [nnn-nn-nnnn] [filename] will run a single inquiry, writing
    the results to both the console and the file specified.  The write
    is appending.

3.  SSN [filename] will enter the interactive mode for multiple
    inquiries, and will write the output of each inquiry to both the
    console and the file specified until you press <esc>.  Again, the
    write is appending.

It is necessary for the data file SSNDATA to reside in the same
directory as the program SSN.EXE, so don't keep them seperate.

This program is offered without warranty as to suitability for a
particular purpose, and should not be relied upon as the sole
reference for decisions involving employment, credit etc.  It is
merely a quick reference compiled from Health and Human Services
data.  Please use other reference bases such as credit headers or
full credit reports to investigate your subject completely before
makeing a decision.

If you have any comments or suggestions about this program or are
interested in custom utilities or other one-off programming
projects, plese contact the author.  We also assist with custom data
telecommunications projects, and information security.  If you are
interested in updates to this program or other programs may have,
plese drop us a line to let us know who you are.


John Bailey
Task Force Software
5311 Miller Ave.
Klamath Falls, OR  97603
503-884-7400
CompuServe 76207,2444


