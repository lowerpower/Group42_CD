/*
	Betrayal at Krondor Cheat v1.00
	Copyright 1993 by Colin Adams and Brett Kapilik
*/

#include <stdio.h>
#include <stdlib.h>


FILE *infile;

void copyright (void);
void loadinfo (void);
void saveinfo (unsigned long newmoney);


void copyright (void) {
		printf("Betrayal at Krondor Cheat v1.00\n");
		printf("Copyright 1993 Colin Adams & Brett Kapilik\n\n");
		printf("Usage: KRONCHT1 saved_file_name\n\n");
}


void loadinfo (void) {
	unsigned long oldmoney;
	char desc[40];

	fread(desc,1,sizeof(desc),infile);
	fseek(infile,0x66,SEEK_SET);
	fread(&oldmoney,1,sizeof(long),infile);
	clrscr();
	printf("Betrayal at Krondor Cheat v1.00\n");
	printf("Copyright 1993 Colin Adams & Brett Kapilik\n\n");
	printf("\nGame description: %s",desc);
	printf("\nYou currently have %lu Royals (%lu Sovereigns)",oldmoney,oldmoney / 10);
}


void saveinfo (unsigned long newmoney) {
	fseek(infile,0x66,SEEK_SET);
	fwrite(&newmoney,1,sizeof(newmoney),infile);
}


int main (int argc, char *argv[]) {
	unsigned long money;

	if (argc<2) {
		copyright();
		exit(1);
	}

	if ((infile = fopen(argv[1],"r+b")) == NULL) {
		copyright();
		printf("Error: Can not open the file %s\n",argv[1]);
		exit(1);
	}
	loadinfo();
	printf("\n\nHow many Royals do you want? (0=No Change): ");
	scanf("%lu",&money);
	if (money==0) {
		fclose(infile);
		printf("\n\nNo changes made to save file!\n\n");
		printf("Thanks for using Betrayal at Krondor Cheat v1.00!\n");
		printf("Programming by Colin Adams and Brett Kapilik\n");
		return(0);
	}
	if (money<0) {
		money=0;
	}
	if (money>99999999) {
		money=99999999;
	}
	saveinfo(money);
	fclose(infile);
	printf("\n\nYou now have %lu Royals (%lu Sovereigns)",money,money / 10);
	printf("\n\nThanks for using Betrayal at Krondor Cheat v1.00!");
	printf("\nProgramming by Colin Adams and Brett Kapilik\n");
	return(0);
}