#include <io.h>
#include <stdio.h>
#include <fcntl.h>
#include <dos.h>

#define uchar unsigned char

typedef struct
{
    char    padding[36];
    uchar   payload;
    uchar   fuel;
    uchar   armor;
    uchar   topspeed;
    uchar   accel;
    uchar   turning;

} SHIPDAT0;

void main( void )
{
    int handle;
    SHIPDAT0 sdat;

    /* This is a fake file to screw us over. */
    remove( "SHIPDAT0.Z66" );

    /* Real stats are stored here. */
    handle = open( "MAPADAT3.Z66", O_BINARY | O_RDWR );
    lseek( handle, 1423L, SEEK_SET );
    _read( handle, &sdat, sizeof sdat );
    lseek( handle, 1423L, SEEK_SET );

    sdat.payload = 255;         /* Max, because uchars are used. */
    sdat.fuel = 120;            /* Bleah.  You guess. */
    sdat.accel = 1;             /* 0 = EXCELLENT, 4 = POOR */
    sdat.turning = 1;           /* Ditto */
    sdat.topspeed = 7;          /* DON'T GO OVER 7! */
    sdat.armor = 120;           /* Doesn't really work */

    _write( handle, &sdat, sizeof sdat );
    close( handle );

    puts( "Patch done!" );
}
